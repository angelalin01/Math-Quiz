package edu.upenn.cis350.hw4;
import edu.upenn.cis350.hw4.R;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    String clickedItem = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String[] difficulty = {"Easy", "Medium", "Hard"};
        ArrayAdapter<String> stringArrayAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, difficulty);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        // add adapter to spinner
        spinner.setAdapter(stringArrayAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // put code which recognize a selected element
                clickedItem = (String) parent.getItemAtPosition(position);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    public void onStartButtonClick(View view) {
        Intent i = new Intent(this, QuizActivity.class);
        if (clickedItem.equals("Easy")) {
            i.putExtra("difficulty", "Easy");
        } else if (clickedItem.equals("Medium")) {
            i.putExtra("difficulty", "Medium");
        } else {
            i.putExtra("difficulty", "Hard");
        }
        startActivity(i);

    }


}
