package edu.upenn.cis350.hw4;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import androidx.appcompat.app.AppCompatActivity;

public class QuizActivity extends AppCompatActivity {

    int easyCounter = 0;
    int mediumCounter = 0;
    int hardCounter = 0;
    boolean isCorrect = false;
    int correctCounter = 0;
    int incorrectCounter = 0;
    boolean isIncorrect = true;

    int easyFirst = 0;
    int easySecond = 0;
    int mediumFirst = 0;
    int mediumSecond = 0;
    int hardFirst = 0;
    int hardSecond = 0;
    int rightAnswer = 0;

    boolean isEasy = false;
    boolean isMedium = false;
    boolean isHard = false;


    //helper functions
    public void randomEasy() {
        Random rand = new Random();
        int randIntFirst = rand.nextInt(9-1+1)+1; // has to be between 1 and 9
        int difference = 10 - randIntFirst;
        int randIntSecond = rand.nextInt(difference - 1-1+1)+1;
        int randIntThird = rand.nextInt(9-1+1)+1;
        int secondDifference = 10 - randIntThird;
        int randIntFourth = rand.nextInt(secondDifference - 1-1+1)+1;
        easyFirst = randIntThird * 10 + randIntFirst;
        easySecond = randIntFourth * 10 + randIntSecond;
        rightAnswer = easyFirst + easySecond;
    }

    public void randomMedium() {
        mediumCounter++;
        if (mediumCounter % 2 == 0) {
            Random rand = new Random();
            int randIntFirst = rand.nextInt(9-1+1)+1;
            int difference = 10 - randIntFirst;
            int randIntSecond = rand.nextInt(difference - 1-1+1)+1;
            int randIntThird = rand.nextInt(7-1+1)+1;
            int min = 10 - randIntThird - 1;
            int randIntFourth = rand.nextInt((8 - min) + 1) + min;
            mediumFirst = randIntThird * 10 + randIntFirst;
            mediumSecond = randIntFourth * 10 + randIntSecond;
            rightAnswer = mediumFirst + mediumSecond;
        } else {
            Random rand = new Random();
            int randIntFirst = rand.nextInt(9-1+1)+1;
            int min = 10 - randIntFirst;
            int randIntSecond = rand.nextInt((8 - min) + 1) + min;
            int randIntThird = rand.nextInt(7-1+1)+1;
            int minSecond = 10 - randIntThird - 1;
            int randIntFourth = rand.nextInt(minSecond - 1-1+1)+1;
            mediumFirst = randIntThird * 10 + randIntFirst;
            mediumSecond = randIntFourth * 10 + randIntSecond;
            rightAnswer = mediumFirst + mediumSecond;
        }

    }

    public void randomHard() {
        Random rand = new Random();
        int randIntFirst = rand.nextInt(9);
        int min = 10 - randIntFirst - 1;
        int randIntSecond = rand.nextInt((9 - min) + 1) + min;
        int randIntThird = rand.nextInt(9-1+1)+1;
        int minSecond = 10 - randIntThird - 1;
        int randIntFourth = rand.nextInt((9 - minSecond) + 1) + minSecond;
        hardFirst = randIntThird * 10 + randIntFirst;
        hardSecond = randIntFourth * 10 + randIntSecond;
        rightAnswer = hardFirst + hardSecond;
    }

    //onCreate
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        correctCounter = 0;
        incorrectCounter = 0;
        String msg = getIntent().getStringExtra("difficulty");
        TextView firstNumber = findViewById(R.id.firstNumberAdded);
        TextView secondNumber = findViewById(R.id.secondNumberAdded);
        if (msg.equals("Easy")) {
            isEasy = true;
            randomEasy();
            String first = Integer.toString(easyFirst);
            String second = Integer.toString(easySecond);
            firstNumber.setText((CharSequence) "  " + first);
            secondNumber.setText((CharSequence) "+ " + second);
        } else if (msg.equals("Medium")) {
            isMedium = true;
            randomMedium();
            String first = Integer.toString(mediumFirst);
            String second = Integer.toString(mediumSecond);
            firstNumber.setText((CharSequence) "  " + first);
            secondNumber.setText((CharSequence) "+ " + second);
        } else {
            isHard = true;
            randomHard();
            String first = Integer.toString(hardFirst);
            String second = Integer.toString(hardSecond);
            firstNumber.setText((CharSequence) "  " + first);
            secondNumber.setText((CharSequence) "+ " + second);
        }
    }

    public void onClearClick(View view) {
        Button clear = (Button)findViewById(R.id.clear);
        if (view == clear) {
            TextView answer = (TextView)findViewById(R.id.answer);
            answer.setText("     ");
        }
    }


    public void onSubmitClick(View view) {
        Button submit = (Button)findViewById(R.id.submit);
        if (view == submit) {
            TextView answer = (TextView)findViewById(R.id.answer);
            String answerString = answer.getText().toString();
            if (Integer.valueOf(answerString) == rightAnswer) {
                isCorrect = true;
            }
            if (isCorrect) {
                isIncorrect = false;
                correctCounter++;
                if (correctCounter > 1) {
                    Toast.makeText(this, "Correct! " + correctCounter + " in a row!",
                            Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "Correct!", Toast.LENGTH_LONG).show();
                }
                isCorrect = false;
                // 2. Create an anonymous AsyncTask object
                new AsyncTask<String, String, String>() {

                    // 3. Implement this method so that it waits for 3 seconds
                    protected String doInBackground(String... inputs) {
                        try { Thread.sleep(3000); }
                        catch (Exception e) { }
                        return null;
                    }

                    // 4. This method will be run after doInBackground finishes
                    protected void onPostExecute(String input) {
                        // 5. This is where you would update the Views in the UI
                        //need to reset the numbers
                        TextView answer = (TextView)findViewById(R.id.answer);
                        answer.setText((CharSequence) "    ?");
                        if (isEasy) {
                            isEasy = true;
                            randomEasy();
                            String first = Integer.toString(easyFirst);
                            String second = Integer.toString(easySecond);
                            TextView firstNumber = findViewById(R.id.firstNumberAdded);
                            TextView secondNumber = findViewById(R.id.secondNumberAdded);
                            firstNumber.setText((CharSequence) "  " + first);
                            secondNumber.setText((CharSequence) "+ " + second);

                        } else if (isMedium) {
                            isMedium = true;
                            randomMedium();
                            String first = Integer.toString(mediumFirst);
                            String second = Integer.toString(mediumSecond);
                            TextView firstNumber = findViewById(R.id.firstNumberAdded);
                            TextView secondNumber = findViewById(R.id.secondNumberAdded);
                            firstNumber.setText((CharSequence) "  " + first);
                            secondNumber.setText((CharSequence) "+ " + second);
                        } else {
                            isHard = true;
                            randomHard();
                            String first = Integer.toString(hardFirst);
                            String second = Integer.toString(hardSecond);
                            TextView firstNumber = findViewById(R.id.firstNumberAdded);
                            TextView secondNumber = findViewById(R.id.secondNumberAdded);
                            firstNumber.setText((CharSequence) "  " + first);
                            secondNumber.setText((CharSequence) "+ " + second);
                        }
                    }
                }.execute();

                //IS INCORRECT
            } else {
                isIncorrect = true;
                if (incorrectCounter == 2) {
                    Toast.makeText(this, "Incorrect Answer! Correct answer is" +
                            rightAnswer, Toast.LENGTH_LONG).show();
                    answer.setText((CharSequence) Integer.toString(rightAnswer));
                    incorrectCounter = 0;
                    new AsyncTask<String, String, String>() {

                        // 3. Implement this method so that it waits for 3 seconds
                        protected String doInBackground(String... inputs) {
                            try { Thread.sleep(3000); }
                            catch (Exception e) { }
                            return null;
                        }
                        TextView answer = (TextView)findViewById(R.id.answer);
                        // 4. This method will be run after doInBackground finishes
                        protected void onPostExecute(String input) {
                            answer.setText((CharSequence) Integer.toString(rightAnswer));
                            if (isEasy) {
                                isEasy = true;
                                randomEasy();
                                String first = Integer.toString(easyFirst);
                                String second = Integer.toString(easySecond);
                                TextView firstNumber = findViewById(R.id.firstNumberAdded);
                                TextView secondNumber = findViewById(R.id.secondNumberAdded);
                                firstNumber.setText((CharSequence) "  " + first);
                                secondNumber.setText((CharSequence) "+ " + second);
                                TextView answer = (TextView)findViewById(R.id.answer);
                                answer.setText((CharSequence) "    ?");
                            } else if (isMedium) {
                                isMedium = true;
                                randomMedium();
                                String first = Integer.toString(mediumFirst);
                                String second = Integer.toString(mediumSecond);
                                TextView firstNumber = findViewById(R.id.firstNumberAdded);
                                TextView secondNumber = findViewById(R.id.secondNumberAdded);
                                firstNumber.setText((CharSequence) "  " + first);
                                secondNumber.setText((CharSequence) "+ " + second);
                                TextView answer = (TextView)findViewById(R.id.answer);
                                answer.setText((CharSequence) "    ?");
                            } else {
                                isHard = true;
                                randomHard();
                                String first = Integer.toString(hardFirst);
                                String second = Integer.toString(hardSecond);
                                TextView firstNumber = findViewById(R.id.firstNumberAdded);
                                TextView secondNumber = findViewById(R.id.secondNumberAdded);
                                firstNumber.setText((CharSequence) "  " + first);
                                secondNumber.setText((CharSequence) "+ " + second);
                                TextView answer = (TextView)findViewById(R.id.answer);
                                answer.setText((CharSequence) "    ?");
                            }

                        }
                    }.execute();
                } else {
                    if (isIncorrect) {
                        incorrectCounter++;
                    }
                    Toast.makeText(this, "Incorrect Answer!", Toast.LENGTH_LONG).show();
                    new AsyncTask<String, String, String>() {

                        // 3. Implement this method so that it waits for 3 seconds
                        protected String doInBackground(String... inputs) {
                            try { Thread.sleep(3000); }
                            catch (Exception e) { }
                            return null;
                        }

                        // 4. This method will be run after doInBackground finishes
                        protected void onPostExecute(String input) {
                            TextView answer = (TextView)findViewById(R.id.answer);
                            answer.setText((CharSequence) "    ?");
                        }
                    }.execute();
                }

            }

        }
    }

    public void onNumberClick(View view) {
        Button buttonZero = (Button)findViewById(R.id.zero);
        Button buttonOne = (Button)findViewById(R.id.one);
        Button buttonTwo = (Button)findViewById(R.id.two);
        Button buttonThree = (Button)findViewById(R.id.three);
        Button buttonFour = (Button)findViewById(R.id.four);
        Button buttonFive = (Button)findViewById(R.id.five);
        Button buttonSix = (Button)findViewById(R.id.six);
        Button buttonSeven = (Button)findViewById(R.id.seven);
        Button buttonEight = (Button)findViewById(R.id.eight);
        Button buttonNine = (Button)findViewById(R.id.nine);
        TextView answer = (TextView)findViewById(R.id.answer);
        if (answer.getText().toString().equals("    ?")) {
            answer.setText("");
        }
        if (view == buttonZero) {
            CharSequence zero = buttonZero.getText();
            String newDigit = "";
            if (answer.getText() != null) {
                newDigit = zero.toString() + answer.getText().toString();
            } else {
                newDigit = zero.toString();
            }
            answer.setText((CharSequence) newDigit);
        }
        if (view == buttonOne) {
            CharSequence one = buttonOne.getText();
            String newDigit = "";
            if (answer.getText() != null) {
                newDigit = one.toString() + answer.getText().toString();
            } else {
                newDigit = one.toString();
            }
            answer.setText((CharSequence) newDigit);
        }
        if (view == buttonTwo) {
            CharSequence two = buttonTwo.getText();
            String newDigit = "";
            if (answer.getText() != null) {
                newDigit = two.toString() + answer.getText().toString();
            } else {
                newDigit = two.toString();
            }
            answer.setText((CharSequence) newDigit);
        }
        if (view == buttonThree) {
            CharSequence three = buttonThree.getText();
            String newDigit = "";
            if (answer.getText() != null) {
                newDigit = three.toString() + answer.getText().toString();
            } else {
                newDigit = three.toString();
            }
            answer.setText((CharSequence) newDigit);
        }
        if (view == buttonFour) {
            CharSequence four = buttonFour.getText();
            String newDigit = "";
            if (answer.getText() != null) {
                newDigit = four.toString() + answer.getText().toString();
            } else {
                newDigit = four.toString();
            }
            answer.setText((CharSequence) newDigit);
        }
        if (view == buttonFive) {
            CharSequence five = buttonFive.getText();
            String newDigit = "";
            if (answer.getText() != null) {
                newDigit = five.toString() + answer.getText().toString();
            } else {
                newDigit = five.toString();
            }
            answer.setText((CharSequence) newDigit);
        }
        if (view == buttonSix) {
            CharSequence six = buttonSix.getText();
            String newDigit = "";
            if (answer.getText() != null) {
                newDigit = six.toString() + answer.getText().toString();
            } else {
                newDigit = six.toString();
            }
            answer.setText((CharSequence) newDigit);
        }
        if (view == buttonSeven) {
            CharSequence seven = buttonSeven.getText();
            String newDigit = "";
            if (answer.getText() != null) {
                newDigit = seven.toString() + answer.getText().toString();
            } else {
                newDigit = seven.toString();
            }
            answer.setText((CharSequence) newDigit);
        }
        if (view == buttonEight) {
            CharSequence eight = buttonEight.getText();
            String newDigit = "";
            if (answer.getText() != null) {
                newDigit = eight.toString() + answer.getText().toString();
            } else {
                newDigit = eight.toString();
            }
            answer.setText((CharSequence) newDigit);
        }
        if (view == buttonNine) {
            CharSequence nine = buttonNine.getText();
            String newDigit = "";
            if (answer.getText() != null) {
                newDigit = nine.toString() + answer.getText().toString();
            } else {
                newDigit = nine.toString();
            }
            answer.setText((CharSequence) newDigit);
        }

    }
}
